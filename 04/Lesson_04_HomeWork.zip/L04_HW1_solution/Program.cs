using System;
using System.Globalization;
using System.Text;
using System.Threading;

class Program
{
	[Flags]
	public enum PackageSizeType
	{
		None = 0x00,
		Small = 0x01,
		Medium = 0x01 << 1,
		Large = 0x01 << 2
	}

	public static void Main()
	{
		// Initialize console 
		Thread.CurrentThread.CurrentCulture = CultureInfo.InvariantCulture;
		Thread.CurrentThread.CurrentUICulture = CultureInfo.InvariantCulture;
		Console.InputEncoding = Encoding.Unicode;
		Console.OutputEncoding = Encoding.Unicode;

		// Declare constants
		const int smallSizePackage = 1;
		const int mediumSizePackage = 5;
		const int largeSizePackage = 20;

		// Request input data
		Console.WriteLine("Какой объем сока (в литрах) требуется упаковать?");
		float rawInputValue = float.Parse(Console.ReadLine());

		// Calculate data
		int numberOfLargePackages = (int)MathF.Floor(rawInputValue / largeSizePackage);
		float rest = rawInputValue - numberOfLargePackages * largeSizePackage;

		int numberOfMediumPackages = (int)MathF.Floor(rest / mediumSizePackage);
		rest = rest - numberOfMediumPackages * mediumSizePackage;

		int numberOfSmallPackages = (int)MathF.Ceiling(rest / smallSizePackage);

		var packageTypesRequired = PackageSizeType.None;
		if (numberOfLargePackages > 0)
			packageTypesRequired |= PackageSizeType.Large;
		if (numberOfMediumPackages > 0)
			packageTypesRequired |= PackageSizeType.Medium;
		if (numberOfSmallPackages > 0)
			packageTypesRequired |= PackageSizeType.Small;

		// Write out the resuts
		Console.WriteLine("Вам потребуются следующие контейнеры:");

		if ((packageTypesRequired & PackageSizeType.Large) == PackageSizeType.Large)
			Console.WriteLine($"{largeSizePackage} л: {numberOfLargePackages} шт.");

		if ((packageTypesRequired & PackageSizeType.Medium) == PackageSizeType.Medium)
			Console.WriteLine($"{mediumSizePackage} л: {numberOfMediumPackages} шт.");

		if ((packageTypesRequired & PackageSizeType.Small) == PackageSizeType.Small)
			Console.WriteLine($"{smallSizePackage} л: {numberOfSmallPackages} шт.");
	}
}

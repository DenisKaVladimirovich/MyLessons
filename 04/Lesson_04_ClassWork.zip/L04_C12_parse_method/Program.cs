using System;

class Program
{
	static void Main()
	{
		string strInt = "12";
		int i = Int32.Parse(strInt);
		Console.WriteLine(i * i); // 144

		string strFloat = "3.14159265";
		float f = Single.Parse(strFloat);
		Console.WriteLine(f * 2); // 6.283185

		string strBool = "true";
		bool b = Boolean.Parse(strBool);
		Console.WriteLine(b.ToString()); // True

		int x;
		x = int.Parse("17");
		Console.WriteLine(x);

		int y = -1;
		bool ok = int.TryParse("bad value", out y);
		Console.WriteLine(ok);
		Console.WriteLine(y);

		if(int.TryParse("", out y))
		{
			// here we can be sure that y has a value
		}
	}
}
using System;

class Program
{
	static void Main()
	{
		double i = 9.49;
		double j = 9.5;
		double k = 10.49;
		double l = 10.5;
		double m = 10.51;
		Console.WriteLine(Convert.ToInt32(i)); // 9
		Console.WriteLine(Convert.ToInt32(j)); // 10
		Console.WriteLine(Convert.ToInt32(k)); // 10
		Console.WriteLine(Convert.ToInt32(l)); // it will be just 10
		Console.WriteLine(Convert.ToInt32(m)); // 11

		Console.WriteLine(Math.Round(10.5, MidpointRounding.ToEven)); // 10
		Console.WriteLine(Math.Round(10.5, MidpointRounding.AwayFromZero)); // 11

		Console.WriteLine(Math.Round(4.0/3, 2)); // 1.33
	}
}
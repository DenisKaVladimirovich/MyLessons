using System;

class Program
{
	enum Day { Sunday, Monday, Tuesday, Wednesday, Thursday, Friday, Saturday };
	enum Month : byte { Jan, Feb, Mar, Apr, May, Jun, Jul, Aug, Sep, Oct, Nov, Dec };

	public static void Main()
	{
		Day today = Day.Monday;
		int dayNumber = (int)today;
		Console.WriteLine("{0} is day number #{1}.", today, dayNumber);

		Month thisMonth = Month.Dec;
		byte monthNumber = (byte)thisMonth;
		Console.WriteLine("{0} is month number #{1}.", thisMonth, monthNumber);

		// Monday is day number #1.
		// Dec is month number #11.
	}
}

using System; // a semicolon indicates the end of a statement class

class Program
{			// start of external block
	static void Main()
	{		// start of inner block
		Console.WriteLine("Hello World!"); // this is one statement
	}		// end of inner block
}			// end of external block

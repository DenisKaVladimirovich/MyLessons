﻿using System;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading;

namespace L02_HW2_solution
{
  internal class Program
  {
    private static void Main()
    {
      Thread.CurrentThread.CurrentCulture = CultureInfo.InvariantCulture;
      Thread.CurrentThread.CurrentUICulture = CultureInfo.InvariantCulture;
      Console.InputEncoding = Encoding.Unicode;
      Console.OutputEncoding = Encoding.Unicode;

      double operand1;
      double operand2;
      char mathOperator;
      double result;
      ConsoleColor defaultColor = Console.ForegroundColor;

      char[] operators = new[] { '+', '-', '*', '/', '%', '^' };

      Console.WriteLine("Calculator");
      Console.WriteLine($"Operands range: {double.MinValue}–{double.MaxValue}");
      Console.WriteLine($"Use \"{CultureInfo.CurrentCulture.NumberFormat.NumberDecimalSeparator}\""
                        + " as a fractional part separator");
      Console.WriteLine($"Use one of the following operators: {string.Join(" ", operators)}");
      Console.WriteLine();

      while (true)
      {
        Console.Write("Enter the 1st operand: ");
        if (double.TryParse(Console.ReadLine(), out operand1))
          break;
        Console.ForegroundColor = ConsoleColor.Red;
        Console.Write("Wrong value! ");
        Console.ForegroundColor = defaultColor;
      }

      while (true)
      {
        Console.Write("Enter the 2nd operand: ");
        if (double.TryParse(Console.ReadLine(), out operand2))
          break;
        Console.ForegroundColor = ConsoleColor.Red;
        Console.Write("Wrong value! ");
        Console.ForegroundColor = defaultColor;
      }

      while (true)
      {
        Console.Write("Enter the operator : ");
        var mathOperatorSource = Console.ReadLine();

        if (mathOperatorSource != null
            && mathOperatorSource.Length == 1
            && operators.Contains(mathOperatorSource[0]))
        {
          mathOperator = mathOperatorSource[0];
          break;
        }

        Console.ForegroundColor = ConsoleColor.Red;
        Console.Write("Wrong value! ");
        Console.ForegroundColor = defaultColor;
      }

      switch (mathOperator)
      {
        case '+':
          result = operand1 + operand2;
          break;
        case '-':
          result = operand1 - operand2;
          break;
        case '*':
          result = operand1 * operand2;
          break;
        case '/':
          result = operand1 / operand2;
          break;
        case '%':
          result = operand1 % operand2;
          break;
        default:
          result = Math.Pow(operand1, operand2);
          break;
      }

      Console.Write($"\n{operand1} {mathOperator} {operand2} = ");
      Console.ForegroundColor = ConsoleColor.Green;
      Console.WriteLine($"{result}");
      Console.ForegroundColor = defaultColor;
    }
  }
}

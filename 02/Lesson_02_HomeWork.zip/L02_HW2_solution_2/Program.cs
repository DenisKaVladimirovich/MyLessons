﻿using System;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading;

namespace L02_HW2_solution_2
{
  internal class Program
  {
    private static void Main()
    {
      char[] operators = { '+', '-', '*', '/', '%', '^' };

      InitializeConsole();
      WriteTitle(operators);

      double operand1 = ReadOperand("1st");
      double operand2 = ReadOperand("2nd");
      char mathOperator = ReadOperator(operators);
      double result = DoCalculation(operand1, operand2, mathOperator);

      WriteResult(operand1, operand2, mathOperator, result);
    }

    private static void InitializeConsole()
    {
      Thread.CurrentThread.CurrentCulture = CultureInfo.InvariantCulture;
      Thread.CurrentThread.CurrentUICulture = CultureInfo.InvariantCulture;
      Console.InputEncoding = Encoding.Unicode;
      Console.OutputEncoding = Encoding.Unicode;
    }
    private static void WriteTitle(char[] operators)
    {
      WriteWithGreen("Calculator\n");
      Console.WriteLine($"  Use operands range: {double.MinValue}–{double.MaxValue}");
      Console.WriteLine($"  Use \"{CultureInfo.CurrentCulture.NumberFormat.NumberDecimalSeparator}\""
                        + " as a fractional part separator");
      Console.WriteLine($"  Use one of the following operators: {string.Join(" ", operators)}");
      Console.WriteLine();
    }

    private static double ReadOperand(string operandDescription)
    {
      double operand;

      while (true)
      {
        Console.Write($"Enter the {operandDescription} operand: ");
        if (double.TryParse(Console.ReadLine(), out operand))
          break;

        WriteWithRed("Wrong value! ");
      }

      return operand;
    }

    private static char ReadOperator(char[] operators)
    {
      char mathOperator;
      while (true)
      {
        Console.Write("Enter the operator : ");
        var mathOperatorSource = Console.ReadLine();

        if (mathOperatorSource != null
            && mathOperatorSource.Length == 1
            && operators.Contains(mathOperatorSource[0]))
        {
          mathOperator = mathOperatorSource[0];
          break;
        }

        WriteWithRed("Wrong value! ");
      }

      return mathOperator;
    }

    private static double DoCalculation(double operand1, double operand2, char mathOperator)
    {
      double result;
      switch (mathOperator)
      {
        case '+':
          result = operand1 + operand2;
          break;
        case '-':
          result = operand1 - operand2;
          break;
        case '*':
          result = operand1 * operand2;
          break;
        case '/':
          result = operand1 / operand2;
          break;
        case '%':
          result = operand1 % operand2;
          break;
        default:
          result = Math.Pow(operand1, operand2);
          break;
      }

      return result;
    }

    private static void WriteResult(double operand1, double operand2, char mathOperator, double result)
    {
      Console.Write($"\n{operand1} {mathOperator} {operand2} = ");
      WriteWithGreen($"{result}\n");
    }

    private static void WriteWithColor(string text, ConsoleColor color)
    {
      ConsoleColor restoreColor = Console.ForegroundColor;
      Console.ForegroundColor = color;
      Console.Write(text);
      Console.ForegroundColor = restoreColor;
    }

    private static void WriteWithRed(string text)
    {
      WriteWithColor(text, ConsoleColor.Red);
    }

    private static void WriteWithGreen(string text)
    {
      WriteWithColor(text, ConsoleColor.Green);
    }
  }
}

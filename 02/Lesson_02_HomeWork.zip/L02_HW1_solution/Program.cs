using System;

public class Program
{
	public static void Main()
	{
		Console.Write("Enter the first integer value: ");
		int a = int.Parse(Console.ReadLine());

		Console.WriteLine();
		Console.Write("Enter the second integer value: ");
		int b = int.Parse(Console.ReadLine());

		Console.WriteLine(a + b);
		Console.WriteLine(a - b);
		Console.WriteLine(a * b);
	}
}

﻿using System;
using System.Diagnostics;
using System.Globalization;

namespace L02_HW2_solution_4
{
  internal class Program
  {    private static void Main(string[] args)
    {
      CultureInfo cultureInfo = CultureInfo.InvariantCulture;

      if (args?.Length > 0)
      {
        try
        {
          cultureInfo = CultureInfo.CreateSpecificCulture(args[0]);
        }
        catch (Exception e)
        {
          Debug.WriteLine(e.ToString());
        }
      }

      var writer = new ConsoleWriter(cultureInfo);
      var calculator = new Calculator(writer);
      calculator.Run();
    }
  }
}

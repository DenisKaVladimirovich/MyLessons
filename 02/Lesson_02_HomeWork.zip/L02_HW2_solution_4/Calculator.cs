﻿using System;

namespace L02_HW2_solution_4
{
  /// <summary>
  /// Describes the Calculator application.
  /// </summary>
  public class Calculator
  {
    private char[] _operators = { '+', '-', '*', '/', '%', '^' };
    private CalculatorIO _io;

    /// <summary>
    /// Initializes a new instance of the <see cref="Calculator"/> class.
    /// </summary>
    /// <param name="consoleWriter">The console writer.</param>
    public Calculator(ConsoleWriter consoleWriter)
    {
      _io = new CalculatorIO(consoleWriter);
    }

    /// <summary>
    /// Runs the calculation.
    /// </summary>
    public void Run()
    {
      _io.WriteTitle(_operators);

      double operand1 = _io.ReadOperand(_io.TheFirstOperandDescription);
      double operand2 = _io.ReadOperand(_io.TheSecondOperandDescription);
      char mathOperator = _io.ReadOperator(_operators);
      double result = Calculate(operand1, operand2, mathOperator);

      _io.WriteResult(operand1, operand2, mathOperator, result);
    }

    private double Calculate(double operand1, double operand2, char mathOperator)
    {
      double result;
      switch (mathOperator)
      {
        case '+':
          result = operand1 + operand2;
          break;
        case '-':
          result = operand1 - operand2;
          break;
        case '*':
          result = operand1 * operand2;
          break;
        case '/':
          result = operand1 / operand2;
          break;
        case '%':
          result = operand1 % operand2;
          break;
        case '^':
          result = Math.Pow(operand1, operand2);
          break;
        default:
          throw new ArgumentOutOfRangeException(nameof(mathOperator));
      }

      return result;
    }
  }
}

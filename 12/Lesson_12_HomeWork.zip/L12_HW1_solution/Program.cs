﻿using System;

namespace L12_HW1_solution
{
	class Program
	{
		static void Main()
		{
		  var reminders = new ReminderItem[3];

      reminders[0] = new ReminderItem(DateTimeOffset.Parse("2020-03-14"), "Happy birthday!");
		  reminders[1] = new ChatReminderItem(DateTimeOffset.Parse("2021-03-14"), "Happy birthday!", "Slack", "agolyakov");
		  reminders[2] = new PhoneReminderItem(DateTimeOffset.Parse("2020-03-14"), "Happy birthday!", "+7916291XXXX");

		  foreach (var reminder in reminders)
		  {
		    reminder.WriteProperties(); 
        Console.WriteLine();
		  }
		}
	}
}

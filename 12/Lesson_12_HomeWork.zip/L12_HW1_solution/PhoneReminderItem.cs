﻿using System;

namespace L12_HW1_solution
{
	public class PhoneReminderItem: ReminderItem
  {
		public string MobilePhone { get; set; }

		public PhoneReminderItem(DateTimeOffset date, string message, string mobilePhone): base(date, message)
		{
		  MobilePhone = mobilePhone;
		}

		public void WriteProperties()
		{
			Console.WriteLine(
			  $"* {GetType().Name}\n" +
        $"Mobile Phone : {MobilePhone}\n" +
        $"AlarmDate : {AlarmDate}\n" +
				$"AlarmMessage : {AlarmMessage}\n" +
				$"TimeToAlarm : {TimeToAlarm}\n" +
				$"IsOutdated : {IsOutdated}");
		}
	}
}

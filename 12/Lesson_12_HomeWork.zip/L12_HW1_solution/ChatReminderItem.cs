﻿using System;

namespace L12_HW1_solution
{
	public class ChatReminderItem : ReminderItem
  {
		public string ChatName { get; set; }

    public string AccountName { get; set; }

    public ChatReminderItem(DateTimeOffset date, string message, string chat, string account)
      : base(date, message)
		{
		  ChatName = chat;
		  AccountName = account;
		}

		public void WriteProperties()
		{
			Console.WriteLine(
			  $"* {GetType().Name}\n" +
        $"ChatName : {ChatName}\n" +
			  $"AccountName : {AccountName}\n" +
        $"AlarmDate : {AlarmDate}\n" +
				$"AlarmMessage : {AlarmMessage}\n" +
				$"TimeToAlarm : {TimeToAlarm}\n" +
				$"IsOutdated : {IsOutdated}");
		}
	}
}

﻿using System;

namespace L12_HW1_solution
{
	public class ReminderItem
	{
		public DateTimeOffset AlarmDate { get; set; }

		public string AlarmMessage { get; set; }

		public TimeSpan TimeToAlarm => AlarmDate.Subtract(DateTimeOffset.UtcNow);

		public bool IsOutdated => TimeToAlarm <= TimeSpan.Zero;

		public ReminderItem(DateTimeOffset date, string message)
		{
			AlarmDate = date;
			AlarmMessage = message;
		}

		public void WriteProperties()
		{
			Console.WriteLine(
			  $"* {GetType().Name}\n" +
        $"AlarmDate : {AlarmDate}\n" +
				$"AlarmMessage : {AlarmMessage}\n" +
				$"TimeToAlarm : {TimeToAlarm}\n" +
				$"IsOutdated : {IsOutdated}");
		}
	}
}

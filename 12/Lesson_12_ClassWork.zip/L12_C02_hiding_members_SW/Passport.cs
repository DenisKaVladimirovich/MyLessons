﻿using System;

public class Passport : BaseDocument
{
	public string Country { get; set; }

	public string PersonName { get; set; }

	new public string PropertiesString
	{
		get
		{
			return $"{DocName} #{DocNumber} issued "
				   + $"{IssueDate:dd-MM-yy} in "
				   + $"{Country} for {PersonName}";
		}
	}

	new public void WriteToConsole()
	{
		Console.WriteLine(PropertiesString);
	}
}

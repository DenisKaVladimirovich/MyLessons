--CREATE DATABASE Сorrespondence;
--GO
USE Сorrespondence;
GO
-- Таблицы
--
-- Отправление
-- DROP TABLE dbo.PostalItem
CREATE TABLE dbo.PostalItem (
	Id INT NOT NULL,
	[Name] VARCHAR(250) NOT NULL,
	NumberOfPages INT NOT NULL,
);
GO
ALTER TABLE dbo.PostalItem
ADD CONSTRAINT PK_PostalItem PRIMARY KEY CLUSTERED (Id);
GO
-- Контрагент
-- DROP TABLE dbo.Сontractor
CREATE TABLE dbo.Сontractor (
	Id INT NOT NULL,
	[Name] VARCHAR(250) NOT NULL,
	PositionId INT NOT NULL,
);
GO
ALTER TABLE dbo.Сontractor
ADD CONSTRAINT PK_Сontractor PRIMARY KEY CLUSTERED (Id);
GO
-- Позиция
-- DROP TABLE dbo.Position
CREATE TABLE dbo.Position (
	Id INT NOT NULL,
	[Name] VARCHAR(250) NOT NULL,
	CONSTRAINT PK_Position PRIMARY KEY CLUSTERED (Id),
);
GO
-- Город
-- DROP TABLE dbo.City
CREATE TABLE dbo.City (
	Id INT NOT NULL,
	[Name] VARCHAR(250) NOT NULL,
	CONSTRAINT PK_City PRIMARY KEY CLUSTERED (Id),
);
GO
-- Адрес
-- DROP TABLE dbo.Address
CREATE TABLE dbo.Address (
	Id INT NOT NULL,
	CityId INT NOT NULL,
	[Address] VARCHAR(250) NOT NULL,
	CONSTRAINT PK_Address PRIMARY KEY CLUSTERED (Id)
);
GO
-- Статус
-- DROP TABLE dbo.Status
CREATE TABLE dbo.Status (
	Id INT NOT NULL,
	[Name] VARCHAR(20) NOT NULL,
	CONSTRAINT PK_Status PRIMARY KEY CLUSTERED (Id),
);
GO
-- Статус
-- DROP TABLE dbo.SendingStatus
CREATE TABLE dbo.SendingStatus (
	PostalItemItemId INT NOT NULL,
	UpdateStatusDateTime DATETIMEOFFSET NOT NULL,
	StatusId INT NOT NULL,
	SendingContractorId INT NOT NULL,
	SendingAddressId INT NOT NULL,
	ReceivingContractorId INT NOT NULL,
	ReceivingAddressId INT NOT NULL,
	CONSTRAINT PK_SendingStatus PRIMARY KEY CLUSTERED (
		PostalItemItemId,
		UpdateStatusDateTime,
		StatusId,
		SendingContractorId,
		SendingAddressId,
		ReceivingContractorId,
		ReceivingAddressId),
);
GO
-- Внешние ключи
--
-- ALTER TABLE dbo.Address DROP CONSTRAINT FK_Address_CityId
ALTER TABLE dbo.Address
ADD CONSTRAINT FK_Address_CityId FOREIGN KEY (CityId)
	REFERENCES dbo.City(Id)
	ON DELETE CASCADE
	ON UPDATE CASCADE
GO
-- ALTER TABLE dbo.Contractor DROP CONSTRAINT FK_Contractor_PositionId
ALTER TABLE dbo.Contractor
ADD CONSTRAINT FK_Contractor_PositionId FOREIGN KEY (PositionId)
	REFERENCES dbo.Position(Id)
	ON DELETE CASCADE
	ON UPDATE CASCADE
GO
-- ALTER TABLE dbo.SendingStatus DROP CONSTRAINT FK_SendingStatus_PostalItemItemId
ALTER TABLE dbo.SendingStatus
ADD CONSTRAINT FK_SendingStatus_PostalItemItemId FOREIGN KEY (PostalItemItemId)
	REFERENCES dbo.PostalItem(Id)
	ON DELETE CASCADE
	ON UPDATE CASCADE
GO
-- ALTER TABLE dbo.SendingStatus DROP CONSTRAINT FK_SendingStatus_StatusId
ALTER TABLE dbo.SendingStatus
ADD CONSTRAINT FK_SendingStatus_StatusId FOREIGN KEY (StatusId)
	REFERENCES dbo.Status(Id)
	ON DELETE CASCADE
	ON UPDATE CASCADE
GO
-- ALTER TABLE dbo.SendingStatus DROP CONSTRAINT FK_SendingStatus_SendingContractorId
ALTER TABLE dbo.SendingStatus
ADD CONSTRAINT FK_SendingStatus_SendingContractorId FOREIGN KEY (SendingContractorId)
	REFERENCES dbo.Contractor(Id)
GO
-- ALTER TABLE dbo.SendingStatus DROP CONSTRAINT FK_SendingStatus_SendingAddressId
ALTER TABLE dbo.SendingStatus
ADD CONSTRAINT FK_SendingStatus_SendingAddressId FOREIGN KEY (SendingAddressId)
	REFERENCES dbo.Address(Id)
GO
-- ALTER TABLE dbo.ReceivingStatus DROP CONSTRAINT FK_ReceivingStatus_ReceivingContractorId
ALTER TABLE dbo.SendingStatus
ADD CONSTRAINT FK_ReceivingStatus_ReceivingContractorId FOREIGN KEY (ReceivingContractorId)
	REFERENCES dbo.Contractor(Id)
GO
-- ALTER TABLE dbo.ReceivingStatus DROP CONSTRAINT FK_ReceivingStatus_ReceivingAddressId
ALTER TABLE dbo.SendingStatus
ADD CONSTRAINT FK_ReceivingStatus_ReceivingAddressId FOREIGN KEY (ReceivingAddressId)
	REFERENCES dbo.Address(Id)
GO
-- проверка поля на уникальность
-- ALTER TABLE dbo.City DROP CONSTRAINT UQ_City_Name;
ALTER TABLE dbo.City
ADD CONSTRAINT UQ_City_Name UNIQUE (Name);
GO

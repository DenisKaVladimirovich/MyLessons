using System;

class Program
{
	enum FigureType
	{
		Circle = 1,
		Triangle = 2,
		Rectangle = 3
	};

	static void Main()
	{
		double square;
		double length;

		try
		{
			double a;
			double b;

			Console.WriteLine("Введите тип фигуры (1 круг, 2 равносторонний треугольник, 3 прямоугольник): ");
			FigureType figureType = (FigureType)int.Parse(Console.ReadLine());

			switch (figureType)
			{
				case FigureType.Circle:
					Console.WriteLine("Введите радиус круга: ");
					a = double.Parse(Console.ReadLine());
					square = Math.PI * a * a;
					length = 2 * Math.PI * a;
					break;
				case FigureType.Triangle:
					Console.WriteLine("Введите длину стороны равностороннего треугольника: ");
					a = double.Parse(Console.ReadLine());
					square = a * a * Math.Sqrt(3) / 4;
					length = 3 * a;
					break;
				case FigureType.Rectangle:
					Console.WriteLine("Введите длину прямоугольника: ");
					a = double.Parse(Console.ReadLine());
					Console.WriteLine("Введите ширину прямоугольника: ");
					b = double.Parse(Console.ReadLine());
					square = a * b;
					length = 2 * (a + b);
					break;
				default:
					throw new InvalidOperationException("Введенный тип фигуры за рамками возможных значений");
			}
		}
		catch (FormatException e)
		{
			Console.WriteLine("Ошибка! Введено нечисловое значение:");
			Console.WriteLine($"{e.GetType()}: {e.Message}");
			throw;
		}
		catch (InvalidOperationException e)
		{
			Console.WriteLine("Ошибка! Невозможно продолжить вычисление:");
			Console.WriteLine($"{e.GetType()}: {e.Message}");
			throw;
		}

		Console.WriteLine($"Площадь поверхности: {Math.Round(square, 2)}");
		Console.WriteLine($"Длина периметра: {Math.Round(length, 2)}");

		Console.WriteLine("Нажмите любую клавишу для выхода...");
		Console.ReadKey();
	}
}
using System;
using System.Text;

class Program
{
	static void Main()
	{
		string sourceText;

		Console.WriteLine("Введите непустую строку:");
		do
		{
			sourceText = Console.ReadLine();

			if (string.IsNullOrWhiteSpace(sourceText))
			{
				Console.WriteLine("Вы ввели пустую строку :( Попробуйте ещё раз:");
			}
			else
			{
				break;
			}
		} while (true);

		var destinationText = new StringBuilder(sourceText.Length);
		for (int i = sourceText.Length - 1; i > -1; i--)
		{
			destinationText.Append(sourceText[i]);
		}

		Console.WriteLine(destinationText.ToString().ToLowerInvariant());
		Console.WriteLine("Нажмите любую клавишу для выхода...");
		Console.ReadKey();
	}
}
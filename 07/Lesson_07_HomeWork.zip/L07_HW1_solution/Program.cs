using System;

class Program
{
	static void Main()
	{
		string[] words;

		Console.WriteLine("Введите строку из нескольких слов:");
		do
		{
			string line = Console.ReadLine();

			words = line.Split(' ');

			if (words.Length < 2)
			{
				Console.WriteLine("Слишком мало слов :( Попробуйте ещё раз:");
			}
			else
			{
				break;
			}
		} while (true);

		int finalNumberOfWords = 0;
		foreach (string word in words)
		{
			if (word.StartsWith("А", StringComparison.InvariantCultureIgnoreCase))
			{
				finalNumberOfWords++;
			}
		}

		Console.WriteLine($"Количество слов, начинающихся с буквы 'А': {finalNumberOfWords}.");
		Console.WriteLine("Нажмите любую клавишу для выхода...");
		Console.ReadKey();
	}
}
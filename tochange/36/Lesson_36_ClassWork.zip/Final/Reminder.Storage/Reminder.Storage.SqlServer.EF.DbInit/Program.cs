﻿using System;

namespace Reminder.Storage.SqlServer.EF.DbInit
{
	class Program
	{
		static void Main(string[] args)
		{
			Console.WriteLine("Hello World!");
		}
	}
}

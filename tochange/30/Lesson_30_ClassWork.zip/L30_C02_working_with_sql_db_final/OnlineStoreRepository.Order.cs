﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace L30_C02_working_with_sql_db_final
{
	public partial class OnlineStoreRepository: IOrderRepository
	{
		public int GetOrderCount()
		{
			using (SqlConnection connection = GetOpenedSqlConnection())
			{
				var sqlCommand = connection.CreateCommand();
				sqlCommand.CommandType = System.Data.CommandType.Text;
				sqlCommand.CommandText = "SELECT COUNT(*) FROM dbo.[Order]";

				int result = (int)sqlCommand.ExecuteScalar();

				return result;
			}
		}

		public List<string> GetOrderDeiscountList()
		{
			var result = new List<string>();

			using (SqlConnection connection = GetOpenedSqlConnection())
			{
				var sqlCommand = connection.CreateCommand();
				sqlCommand.CommandType = System.Data.CommandType.Text;
				sqlCommand.CommandText = "SELECT Id FROM dbo.[Order] ORDER BY 1 ASC";

				using (SqlDataReader reader = sqlCommand.ExecuteReader())
				{
					if (!reader.HasRows)
						return result;

					int idColumnIndex = reader.GetOrdinal("Id");
					int discountColumnIndex = reader.GetOrdinal("Discount");

					while (reader.Read())
					{
						var id = reader.GetInt32(idColumnIndex);

						var discount = (reader.IsDBNull(discountColumnIndex))
							? 0
							: reader.GetDouble(discountColumnIndex);

						result.Add($"Order ID: {id}, Discount: {discount * 100:0.00}%");
					}
				}

				return result;
			}
		}

		public int AddOrder(
			int customerId,
			DateTimeOffset orderDate,
			float? discount,
			List<Tuple<int, int>>
			productIdCountList)
		{
			int orderId = -1;

			using (SqlConnection connection = GetOpenedSqlConnection())
			using (SqlTransaction transaction = connection.BeginTransaction())
			{
				try
				{
					var sqlCommand = connection.CreateCommand();
					sqlCommand.Transaction = transaction;
					sqlCommand.CommandType = System.Data.CommandType.StoredProcedure;
					sqlCommand.CommandText = "dbo.AddOrder";

					sqlCommand.Parameters.AddWithValue("@customerId", customerId);
					sqlCommand.Parameters.AddWithValue("@orderDate", orderDate);
					if (discount.HasValue)
						sqlCommand.Parameters.AddWithValue("@discount", discount.Value);

					var outputIdParameter = new SqlParameter("@id", System.Data.SqlDbType.Int, 1);
					outputIdParameter.Direction = System.Data.ParameterDirection.Output;
					sqlCommand.Parameters.Add(outputIdParameter);

					sqlCommand.ExecuteNonQuery();

					orderId = (int)outputIdParameter.Value;

					sqlCommand = connection.CreateCommand();
					sqlCommand.Transaction = transaction;
					sqlCommand.CommandType = System.Data.CommandType.StoredProcedure;
					sqlCommand.CommandText = "dbo.AddOrderItem";

					foreach (var productIdCount in productIdCountList)
					{
						sqlCommand.Parameters.Clear();
						sqlCommand.Parameters.AddWithValue("@orderId", orderId);
						sqlCommand.Parameters.AddWithValue("@productId", productIdCount.Item1);
						sqlCommand.Parameters.AddWithValue("@numberOfItems", productIdCount.Item2);

						sqlCommand.ExecuteNonQuery();
					}
				}
				catch (SqlException)
				{
					transaction.Rollback();
					throw;
				}

				transaction.Commit();
			}

			return orderId;
		}
	}
}

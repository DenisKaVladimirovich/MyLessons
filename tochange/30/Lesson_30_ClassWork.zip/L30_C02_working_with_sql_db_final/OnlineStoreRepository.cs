﻿using System.Data.SqlClient;

namespace L30_C02_working_with_sql_db_final
{
	public partial class OnlineStoreRepository : IProductRepository
	{
		private readonly string _connectionString;

		public OnlineStoreRepository(string connectionString)
		{
			_connectionString = connectionString;
		}

		private SqlConnection GetOpenedSqlConnection()
		{
			var sqlConnection = new SqlConnection(_connectionString);
			sqlConnection.Open();

			return sqlConnection;
		}
	}
}

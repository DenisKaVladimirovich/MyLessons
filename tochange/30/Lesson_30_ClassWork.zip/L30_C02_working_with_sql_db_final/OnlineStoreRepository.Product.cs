﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;

namespace L30_C02_working_with_sql_db_final
{
	public partial class OnlineStoreRepository
	{
		public int GetProductCount()
		{
			using (SqlConnection connection = GetOpenedSqlConnection())
			{
				var sqlCommand = connection.CreateCommand();
				sqlCommand.CommandType = System.Data.CommandType.Text;
				sqlCommand.CommandText = "SELECT COUNT(*) FROM dbo.Product";

				int result = (int)sqlCommand.ExecuteScalar();

				return result;
			}
		}

		public List<string> GetProductList()
		{
			var result = new List<string>();

			using (SqlConnection connection = GetOpenedSqlConnection())
			{
				var sqlCommand = connection.CreateCommand();
				sqlCommand.CommandType = System.Data.CommandType.Text;
				sqlCommand.CommandText = "SELECT Id, Name, Price FROM dbo.Product ORDER BY Price ASC";

				using (SqlDataReader reader = sqlCommand.ExecuteReader())
				{
					if (!reader.HasRows)
						return result;

					int idColumnIndex = reader.GetOrdinal("Id");
					int nameColumnIndex = reader.GetOrdinal("Name");
					int priceColumntIndex = reader.GetOrdinal("Price");
					
					while (reader.Read())
					{
						var id = reader.GetInt32(idColumnIndex);
						var name = reader.GetString(nameColumnIndex);
						var price = reader.GetDecimal(priceColumntIndex);

						result.Add($"Product ID: {id}\tName: {name} (Price: {price:0.00} Р.)");
					}
				}

				return result;
			}
		}

		public int AddProduct(string name, decimal price)
		{
			using (SqlConnection connection = GetOpenedSqlConnection())
			{
				var sqlCommand = connection.CreateCommand();
				sqlCommand.CommandType = System.Data.CommandType.StoredProcedure;
				sqlCommand.CommandText = "dbo.AddProduct";

				sqlCommand.Parameters.AddWithValue("@name", name);
				sqlCommand.Parameters.AddWithValue("@price", price);

				var outputIdParameter = new SqlParameter("@id", System.Data.SqlDbType.Int, 1);
				outputIdParameter.Direction = System.Data.ParameterDirection.Output;
				sqlCommand.Parameters.Add(outputIdParameter);

				sqlCommand.ExecuteNonQuery();

				return (int)outputIdParameter.Value;
			}
		}
	}
}

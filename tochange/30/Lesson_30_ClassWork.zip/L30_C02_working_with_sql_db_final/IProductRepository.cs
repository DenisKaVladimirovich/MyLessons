﻿using System.Collections.Generic;

namespace L30_C02_working_with_sql_db_final
{
	public interface IProductRepository
	{
		int GetProductCount();

		List<string> GetProductList();

		int AddProduct(string name, decimal price);
	}
}

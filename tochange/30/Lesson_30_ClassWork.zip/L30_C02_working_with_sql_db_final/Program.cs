﻿using System;
using System.Collections.Generic;

namespace L30_C02_working_with_sql_db_final
{
	class Program
	{
		static void Main(string[] args)
		{
			const string connectionStringTemplate =
				"Data Source={0};Initial Catalog={1};Integrated Security=true;";
			var connectionString = string.Format(
				connectionStringTemplate,
				@"localhost\SQLEXPRESS",
				"OnlineStore");

			var repository = new OnlineStoreRepository(connectionString);

			// playing around with IProductRepository

			int productCount = repository.GetProductCount();
			Console.WriteLine($"Number of product: {productCount}");

			var products = repository.GetProductList();
			foreach (var product in products)
			{
				Console.WriteLine(product);
			}

			int newProductId = repository.AddProduct("Суперчасы", (decimal)12345.67);
			Console.WriteLine($"Product with new ID = {newProductId} added.");

			// playing around with IOrderRepository

			int orderCount = repository.GetOrderCount();
			Console.WriteLine($"Number of orders: {orderCount}");

			var orderIdList = repository.GetOrderDeiscountList();
			foreach (var orderId in orderIdList)
			{
				Console.WriteLine(orderId);
			}

			int newOrderId = repository.AddOrder(
				5, // Света
				DateTimeOffset.Now,
				0.05F,
				new List<Tuple<int, int>>
				{
					// Браслет Xiaomi Mi Band 3 × 2 шт.
					new Tuple<int, int>(1, 2),
					// Суперчасы × 1 шт.
					new Tuple<int, int>(newProductId /* + 1 <- check rollback */, 1)
				});

			Console.WriteLine($"Order with new ID = {newOrderId} added.");
		}
	}
}

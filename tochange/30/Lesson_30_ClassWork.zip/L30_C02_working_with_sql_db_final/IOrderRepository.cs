﻿using System;
using System.Collections.Generic;

namespace L30_C02_working_with_sql_db_final
{
	public interface IOrderRepository
	{
		int GetOrderCount();

		List<string> GetOrderDeiscountList();

		int AddOrder(
			int customerId,
			DateTimeOffset orderDate,
			float? discount,
			List<Tuple<int, int>> 
			productIdCountList);
	}
}

﻿using System;

namespace L30_C01_working_with_sql_db
{
	class Program
	{
		static void Main(string[] args)
		{
			Console.WriteLine("Hello World!");
		}
	}
}

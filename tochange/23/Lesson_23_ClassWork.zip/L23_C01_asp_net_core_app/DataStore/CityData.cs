﻿namespace L23_C01_asp_net_core_app.DataStore
{
	public class CityData
	{
		public int Id { get; set; }

		public string Name { get; set; }

		public string Description { get; set; }

		public int NumberOfPointsOfInterest { get; set; }
	}
}

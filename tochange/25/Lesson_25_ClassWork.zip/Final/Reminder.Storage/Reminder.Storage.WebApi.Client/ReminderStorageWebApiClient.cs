﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using Microsoft.AspNetCore.JsonPatch;
using Microsoft.AspNetCore.JsonPatch.Operations;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using Reminder.Storage.Core;
using Reminder.Storage.WebApi.Core;

namespace Reminder.Storage.WebApi.Client
{
	public class ReminderStorageWebApiClient : IReminderStorage
	{
		private string _baseWebApiUrl;
		private HttpClient _httpClient;

		public ReminderStorageWebApiClient(string baseWebApiUrl)
		{
			_baseWebApiUrl = baseWebApiUrl;
			_httpClient = HttpClientFactory.Create();
		}

		public Guid Add(ReminderItemRestricted reminder)
		{
			var result = CallWebApi(
				"POST",
				"/api/reminders",
				JsonConvert.SerializeObject(new ReminderItemCreateModel(reminder)));

			if (result.StatusCode != System.Net.HttpStatusCode.Created)
			{
				throw GetException(result);
			}

			return JsonConvert
				.DeserializeObject<ReminderItemGetModel>(
					result.Content.ReadAsStringAsync().Result)
				.Id;
		}

		public ReminderItem Get(Guid id)
		{
			var result = CallWebApi(
				"GET",
				 $"/api/reminders/{id}");

			if (result.StatusCode == System.Net.HttpStatusCode.NotFound)
			{
				return null;
			}

			if (result.StatusCode != System.Net.HttpStatusCode.OK)
			{
				throw GetException(result);
			}

			var reminderItemGetModel = JsonConvert.DeserializeObject<ReminderItemGetModel>(
				result.Content.ReadAsStringAsync().Result);

			return reminderItemGetModel.ToReminderItem();
		}

		public List<ReminderItem> Get(ReminderItemStatus status)
		{
			var result = CallWebApi(
				"GET",
				 $"/api/reminders?[filter]status={(int)status}");

			if (result.StatusCode != System.Net.HttpStatusCode.OK)
			{
				throw GetException(result);
			}

			var reminderItemGetModels = JsonConvert.DeserializeObject<List<ReminderItemGetModel>>(
				result.Content.ReadAsStringAsync().Result);

			return reminderItemGetModels
				.Select(x => x.ToReminderItem())
				.ToList();
		}

		public void UpdateStatus(IEnumerable<Guid> ids, ReminderItemStatus status)
		{
			var contentModel = new ReminderItemsUpdateModel
			{
				Ids = ids.ToList(),
				PatchDocument = new JsonPatchDocument<ReminderItemUpdateModel>(
					new List<Operation<ReminderItemUpdateModel>>
					{
					new Operation<ReminderItemUpdateModel>
					{
						op = "replace",
						path = "/status",
						value = (int)status
					}
					},
					new DefaultContractResolver())
			};

			var result = CallWebApi(
				"PATCH",
				$"/api/reminders",
				JsonConvert.SerializeObject(contentModel));

			if (result.StatusCode != System.Net.HttpStatusCode.NoContent)
			{
				throw GetException(result);
			}
		}

		public void UpdateStatus(Guid id, ReminderItemStatus status)
		{
			var patchDocument = new JsonPatchDocument<ReminderItemUpdateModel>(
				new List<Operation<ReminderItemUpdateModel>>
				{
					new Operation<ReminderItemUpdateModel>
					{
						op = "replace",
						path = "/status",
						value = (int)status
					}
				},
				new DefaultContractResolver());

			var result = CallWebApi(
				"PATCH",
				$"/api/reminders/{id}",
				JsonConvert.SerializeObject(patchDocument));

			if (result.StatusCode != System.Net.HttpStatusCode.NoContent)
			{
				throw GetException(result);
			}
		}

		private HttpResponseMessage CallWebApi(
			string method,
			string relativeUrl,
			string content = null)
		{
			var request = new HttpRequestMessage(
				new HttpMethod(method),
				_baseWebApiUrl + relativeUrl);

			request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

			if (method == "POST" || method == "PATCH" || method == "PUT")
			{
				request.Content = new StringContent(
					content,
					Encoding.UTF8,
					"application/json");
			}

			return _httpClient.SendAsync(request).Result;
		}

		private Exception GetException(HttpResponseMessage result)
		{
			return new Exception(
				$"Error: {result.StatusCode}, " +
				$"Content: {result.Content.ReadAsStringAsync().Result}");
		}
	}
}

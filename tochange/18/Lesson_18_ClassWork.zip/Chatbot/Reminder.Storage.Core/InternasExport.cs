﻿using System.Runtime.CompilerServices;
[assembly: InternalsVisibleTo("Reminder.Storage.Core.Tests")]

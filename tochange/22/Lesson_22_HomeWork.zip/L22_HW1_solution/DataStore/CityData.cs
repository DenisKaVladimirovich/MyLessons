﻿namespace L22_HW1_solution.DataStore
{
	public class CityData
	{
		public int Id { get; set; }

		public string Name { get; set; }

		public string Description { get; set; }

		public int NumberOfPointsOfInterest { get; set; }
	}
}

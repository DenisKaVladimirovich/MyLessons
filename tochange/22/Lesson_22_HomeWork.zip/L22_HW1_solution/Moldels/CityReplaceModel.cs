﻿using L22_HW1_solution.DataStore;

namespace L22_HW1_solution.Moldels
{
	public class CityReplaceModel
	{
		public string Name { get; set; }

		public string Description { get; set; }

		public int NumberOfPointsOfInterest { get; set; }

		public CityReplaceModel()
		{
		}

		public CityReplaceModel(CityData city)
		{
			Name = city.Name;
			Description = city.Description;
			NumberOfPointsOfInterest = city.NumberOfPointsOfInterest;
		}
	}
}

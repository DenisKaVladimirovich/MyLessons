﻿using Microsoft.EntityFrameworkCore;
using L35_C01_working_with_ef_core.Domain;

namespace L35_C01_working_with_ef_core.Data
{
	public class OnlineStoreContext : DbContext
	{
		private readonly string _connectionString;

		public DbSet<Product> Products { get; set; }

		public DbSet<Customer> Customers { get; set; }

		public DbSet<OrderItem> OrderItems { get; set; }

		public DbSet<Order> Orders { get; set; }

		public OnlineStoreContext()
		{
			_connectionString =
				@"Data Source=localhost\SQLEXPRESS;" +
				"Initial Catalog=OnlineStoreEF;" +
				"Integrated Security=true;";
		}

		protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
		{
			optionsBuilder.UseSqlServer(_connectionString);
		}

		protected override void OnModelCreating(ModelBuilder modelBuilder)
		{
			modelBuilder
				.Entity<Customer>()
					.HasAlternateKey(p => p.Name)
					.HasName("UQ_Customers_Name");

			modelBuilder
				.Entity<OrderItem>()
					.HasKey("OrderId", "ProductId")
					.HasName("PK_OrderItems")
					.ForSqlServerIsClustered(true);
		}
	}
}

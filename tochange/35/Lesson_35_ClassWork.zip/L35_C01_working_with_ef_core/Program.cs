﻿using System;

namespace L35_C01_working_with_ef_core
{
	class Program
	{
		static void Main(string[] args)
		{
			Console.WriteLine("Hello World!");
		}
	}
}

﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace L35_C01_working_with_ef_core.Domain
{
	public class Customer
	{
		public int Id { get; set; }

		[Required]
		[MaxLength(50)]
		[Column("Name", TypeName = "VARCHAR(50)")]
		public string Name { get; set; }
	}
}

﻿using L35_C02_working_with_ef_core_final.Data;
using L35_C02_working_with_ef_core_final.Domain;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;

namespace L35_C02_working_with_ef_core_final
{
	class Program
	{
		private static OnlineStoreContext _context = new OnlineStoreContext();

		static void Main(string[] args)
		{
			//Console.WriteLine("Hello World!");

			//InsertCustomers();
			//InsertProducts();

			//SelectCustomers();
			//MoreQueries();

			//UpdateCustomers();
			//QueryAndUpdateProductDisconnected();

			//DeleteWhileTracked();
			//DeleteWhileNotTracked();
		}

		private static void InsertCustomers()
		{
			var customer = new Customer { Name = "Alex" };
			using (var context = new OnlineStoreContext())
			{
				context.Customers.Add(customer);
				context.SaveChanges();
			}

			var customers = new[]
			{
				new Customer { Name = "Pavel" },
				new Customer { Name = "Eugeni" }
			};
			using (var context = new OnlineStoreContext())
			{
				context.AddRange(customers);
				context.SaveChanges();
			}
		}

		private static void InsertProducts()
		{
			var product = new Product { Name = "Fenix 5 Plus Sapphire", Price = 73989.99M };
			using (var context = new OnlineStoreContext())
			{
				context.Products.Add(product);
				context.SaveChanges();
			}

			var products = new[]
			{
				new Product { Name = "Forerunner 645 Music", Price = 42199.99M },
				new Product { Name = "MARQ Aviator", Price = 208400 }
			};
			using (var context = new OnlineStoreContext())
			{
				context.AddRange(products);
				context.SaveChanges();
			}
		}

		private static void SelectCustomers()
		{
			using (var context = new OnlineStoreContext())
			{
				var allCustomers = context.Customers.ToList();

				var allCustomersLinqSyntax = (
					from c
					in context.Customers
					select c
				).ToList();

				var severalCustomers = context.Customers
					.Where(c => c.Name.StartsWith("Andrei"))
					.ToList();

				var severalCustomersLinqSyntax = (
					from c
					in context.Customers
					where c.Name.StartsWith("Andrei")
					select c
				).ToList();

				var customersWithNameAndrei = context.Customers
					.Where(c => c.Name.StartsWith("Andrei"))
					.ToList();

				foreach (var customer in customersWithNameAndrei)
				{
					Console.WriteLine(customer.Name);
				}

				foreach (var customer in context.Customers.Where(x => x.Id < 5).ToList())
				{
					Console.WriteLine(customer.Name);
				}
			}
		}

		private static void MoreQueries()
		{
			var customers = _context.Customers.Where(c => c.Name == "Andrei").ToList();

			var name = "Andrei";
			customers = _context.Customers.Where(c => c.Name == name).ToList();

			var customersAndrei = _context.Customers
				.Where(c => c.Name.Contains("Andrei"))
				.ToList();

			var customersAndrei2 = _context.Customers
				.Where(c => EF.Functions.Like(c.Name, "Andrei%"))
				.ToList();
		}

		private static void UpdateCustomers()
		{
			var customer = _context.Customers.First();
			customer.Name = "Mr. " + customer.Name;
			_context.SaveChanges();
		}

		private static void QueryAndUpdateProductDisconnected()
		{
			var product = _context.Products.First();
			product.Price *= 0.1M;

			using (var newContextInstance = new OnlineStoreContext())
			{
				newContextInstance.Products.Update(product);
				newContextInstance.SaveChanges();
			}
		}

		private static void DeleteWhileTracked()
		{
			var customer = _context.Customers.FirstOrDefault(c => c.Name == "Andrei");
			if (customer != null)
			{
				_context.Customers.Remove(customer);
				_context.SaveChanges();
			}
		}

		private static void DeleteWhileNotTracked()
		{
			var customer = _context.Customers.FirstOrDefault(c => c.Name == "Eugeni");
			if (customer != null)
			{
				using (var newContextInstance = new OnlineStoreContext())
				{
					newContextInstance.Customers.Remove(customer);
					newContextInstance.SaveChanges();
				}

				//_context.Database.ExecuteSqlCommand(
				//	"EXEC DELETE FROM [dbo].[Customers] WHERE Id = {0}", 1);
			}
		}
	}
}

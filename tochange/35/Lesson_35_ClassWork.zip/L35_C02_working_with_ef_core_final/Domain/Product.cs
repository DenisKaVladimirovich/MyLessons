﻿namespace L35_C02_working_with_ef_core_final.Domain
{
	public class Product
	{
		public int Id { get; set; }

		public string Name { get; set; }

		public decimal Price { get; set; }
	}
}

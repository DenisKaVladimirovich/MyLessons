﻿using Microsoft.AspNetCore.JsonPatch;
using Microsoft.AspNetCore.JsonPatch.Operations;
using Newtonsoft.Json;
using Reminder.Storage.Core;
using Reminder.Storage.WebApi.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;

namespace Reminder.Storage.WebApi.Client
{
	public class ReminderStorageWebApiClient : IReminderStorage
	{
		private string _baseWebApiUrl;
		private HttpClient _httpClient;

		public ReminderStorageWebApiClient(string baseWebApiUrl)
		{
			_baseWebApiUrl = baseWebApiUrl;
			_httpClient = HttpClientFactory.Create();
		}

		public int Count
		{
			get
			{
				var httpResponseMessage = CallWebApi("HEAD", "/api/reminders", null);
				if (httpResponseMessage.StatusCode != System.Net.HttpStatusCode.OK)
				{
					throw CreateException(httpResponseMessage);
				}

				const string totalCountHeaderName = "X-Total-Count";
				if (!httpResponseMessage.Headers.Contains(totalCountHeaderName))
				{
					throw new Exception($"There is no expected header '{totalCountHeaderName}' found");
				}

				string xTotalCountHeader = httpResponseMessage.Headers
					.GetValues(totalCountHeaderName)
					.FirstOrDefault();

				return int.Parse(xTotalCountHeader);
			}
		}

		public void Add(ReminderItem reminder)
		{
			var reminderItemCreateModel = new ReminderItemCreateModel(reminder);
			var content = JsonConvert.SerializeObject(reminderItemCreateModel);

			var httpResponseMessage = CallWebApi("POST", $"/api/reminders", content);

			if (httpResponseMessage.StatusCode != System.Net.HttpStatusCode.Created)
			{
				throw CreateException(httpResponseMessage);
			}
		}

		public ReminderItem Get(Guid id)
		{
			var httpResponseMessage = CallWebApi("GET", $"/api/reminders/{id}");

			if (httpResponseMessage.StatusCode == System.Net.HttpStatusCode.NotFound)
			{
				return null;
			}

			if (httpResponseMessage.StatusCode != System.Net.HttpStatusCode.OK)
			{
				throw CreateException(httpResponseMessage);
			}

			var reminderItemGetModel = JsonConvert.DeserializeObject<ReminderItemGetModel>(
				httpResponseMessage.Content.ReadAsStringAsync().Result);

			if (reminderItemGetModel == null)
				throw new Exception($"Body cannot be parsed as ReminderItemGetModel.");

			return reminderItemGetModel.ToReminderItem();
		}

		public List<ReminderItem> Get(int count = 0, int startPostion = 0)
		{
			var queryParams = new List<KeyValuePair<string, string>>();

			if (count > 0)
				queryParams.Add(new KeyValuePair<string, string>("[paging]count", count.ToString()));

			if (startPostion > 0)
				queryParams.Add(new KeyValuePair<string, string>("[paging]startPostion", startPostion.ToString()));

			var httpResponseMessage = CallWebApi("GET", "/api/reminders" + BuildQueryString(queryParams));

			if (httpResponseMessage.StatusCode != System.Net.HttpStatusCode.OK)
			{
				throw CreateException(httpResponseMessage);
			}

			var list = JsonConvert.DeserializeObject<List<ReminderItemGetModel>>(
				httpResponseMessage.Content.ReadAsStringAsync().Result);

			if (list == null)
				throw new Exception($"Body cannot be parsed as List<ReminderItemGetModel>.");

			return list
				.Select(m => m.ToReminderItem())
				.ToList();
		}

		public List<ReminderItem> Get(ReminderItemStatus status, int count = 0, int startPostion = 0)
		{
			var queryParams = new List<KeyValuePair<string, string>>();

			queryParams.Add(new KeyValuePair<string, string>("[filter]status", ((int)status).ToString()));

			if (count > 0)
				queryParams.Add(new KeyValuePair<string, string>("[paging]count", count.ToString()));

			if (startPostion > 0)
				queryParams.Add(new KeyValuePair<string, string>("[paging]startPostion", startPostion.ToString()));

			var httpResponseMessage = CallWebApi("GET", "/api/reminders" + BuildQueryString(queryParams));

			if (httpResponseMessage.StatusCode != System.Net.HttpStatusCode.OK)
			{
				throw CreateException(httpResponseMessage);
			}

			var list = JsonConvert.DeserializeObject<List<ReminderItemGetModel>>(
				httpResponseMessage.Content.ReadAsStringAsync().Result);

			if (list == null)
				throw new Exception($"Body cannot be parsed as List<ReminderItemGetModel>.");

			return list
				.Select(m => m.ToReminderItem())
				.ToList();
		}

		public bool Remove(Guid id)
		{
			var httpResponseMessage = CallWebApi("DELETE", $"/api/reminders/{id}");

			if (httpResponseMessage.StatusCode == System.Net.HttpStatusCode.NotFound)
			{
				return false;
			}

			if (httpResponseMessage.StatusCode != System.Net.HttpStatusCode.NoContent)
			{
				throw CreateException(httpResponseMessage);
			}

			return true;
		}

		public void UpdateStatus(IEnumerable<Guid> ids, ReminderItemStatus status)
		{
			var contentObject = new ReminderItemsUpdateModel
			{
				Ids = ids.ToList(),
				PatchDocument = new JsonPatchDocument<ReminderItemUpdateModel>(
					new List<Operation<ReminderItemUpdateModel>>
					{
						new Operation<ReminderItemUpdateModel>
						{
							op = "replace",
							path = "/status",
							value = (int)status
						}
					},
					new Newtonsoft.Json.Serialization.DefaultContractResolver())
			};
			
			var content = JsonConvert.SerializeObject(contentObject);

			var httpResponseMessage = CallWebApi("PATCH", $"/api/reminders", content);

			if (httpResponseMessage.StatusCode != System.Net.HttpStatusCode.NoContent)
			{
				throw CreateException(httpResponseMessage);
			}
		}

		public void UpdateStatus(Guid id, ReminderItemStatus status)
		{
			var patchDocument = new JsonPatchDocument<ReminderItemUpdateModel>(
				new List<Operation<ReminderItemUpdateModel>>
				{
					new Operation<ReminderItemUpdateModel>
					{
						op = "replace",
						path = "/status",
						value = (int)status
					}
				},
				new Newtonsoft.Json.Serialization.DefaultContractResolver());

			var content = JsonConvert.SerializeObject(patchDocument);

			var httpResponseMessage = CallWebApi("PATCH", $"/api/reminders/{id}", content);

			if (httpResponseMessage.StatusCode != System.Net.HttpStatusCode.NoContent)
			{
				throw CreateException(httpResponseMessage);
			}
		}

		private HttpResponseMessage CallWebApi(
			string method,
			string relativeUrl,
			string content = null)
		{
			HttpMethod httpMethod = new HttpMethod(method);

			var request = new HttpRequestMessage(
				httpMethod,
				_baseWebApiUrl + relativeUrl);

			request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("*/*"));

			if (method == "POST" || method == "PUT" || method == "PATCH")
			{
				request.Content = new StringContent(
					content,
					Encoding.UTF8,
					"application/json");
			}

			return _httpClient.SendAsync(request).Result;
		}

		private string BuildQueryString(List<KeyValuePair<string, string>> queryParams)
		{
			if (queryParams?.Count == 0)
				return string.Empty;

			return "?" + string.Join(
				"&",
				queryParams
					.Select(kvp => kvp.Key + "=" + kvp.Value)
					.ToArray());
		}

		private Exception CreateException(HttpResponseMessage httpResponseMessage)
		{
			return new Exception(
				$"Status code: {httpResponseMessage.StatusCode}.\n" +
				$"Content:\n{httpResponseMessage.Content.ReadAsStringAsync().Result}");
		}
	}
}

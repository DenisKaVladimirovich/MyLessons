﻿namespace L15_HW1_solution.LogWriter
{
	public enum LogRecordType
	{
		Info,
		Warning,
		Error
	}
}

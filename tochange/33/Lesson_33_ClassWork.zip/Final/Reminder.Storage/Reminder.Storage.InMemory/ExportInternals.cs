﻿using System.Runtime.CompilerServices;
[assembly: InternalsVisibleTo("Reminder.Storage.InMemory.Tests")]
USE QueryTests
GO
DROP PROCEDURE IF EXISTS [dbo].[CreateCategory]
GO
-- SP будет вставлять новую категорию в таблицу и возвращать нам GUID этой категории.
CREATE PROCEDURE dbo.CreateCategory (
	@categoryName AS VARCHAR(50), -- like in the field Name of table Category
	@guid AS UNIQUEIDENTIFIER OUTPUT
)
AS
BEGIN
	-- отключене сообщение о количестве изменённых записей
	-- (best practice)
	SET NOCOUNT ON

	-- объявляем переменную идентификатора
	DECLARE @tempGuid AS UNIQUEIDENTIFIER
	SET @tempGuid = NEWID()

	INSERT INTO dbo.Category (Id, [Name])
	VALUES (@tempGuid, @categoryName)

	SET @guid = @tempGuid
END
GO
DECLARE @guid AS UNIQUEIDENTIFIER
-- проверяем, как работает наша функция на точном соответствии
EXECUTE dbo.CreateCategory @categoryName  = 'TEST', @guid = @guid OUTPUT
SELECT @guid AS Id
DELETE FROM dbo.Category WHERE [Name] = 'TEST'
GO
--
--
--
DROP PROCEDURE IF EXISTS [dbo].[CreateGoodsItem]
GO
-- 
CREATE PROCEDURE dbo.CreateGoodsItem (
	@categoryName AS VARCHAR(50),
	@goodsItemName AS NVARCHAR(100),
	@goodsItemId AS INT OUTPUT
)
AS
BEGIN
	SET NOCOUNT ON
	
	-- объявляем переменную идентификатора категории
	DECLARE @guid AS UNIQUEIDENTIFIER

	-- пытаемся её найти с помощью нашей функции
	SELECT @guid = dbo.GetCategoryId(@categoryName)

	-- включаем автоматический откат текущей транзакции,
	-- если внутри транзакции происходит ошибка выполнения.
	SET XACT_ABORT ON;
	
	-- начинаем транзакцию
	BEGIN TRANSACTION
	-- начинаем блок try
	BEGIN TRY
		-- если не получилось найти категорию по имени, пытаемся её создать
		IF (@guid IS NULL)
			EXECUTE dbo.CreateCategory @categoryName, @guid OUTPUT

		-- далее пробем вставить товар с указанной категорией.
		-- тут может возникнуть проблема со вставкой нового товара,
		-- например, нарушено ограничение на уникальность имени товара.
		-- в таком случае создание новой категории (для этого товара),
		-- выполненное выше с помощью dbo.CreateCategory, имело бы смысл отменить.
		INSERT INTO dbo.Goods(CategoryId, [Name])
		VALUES (@guid, @goodsItemName)
		SET @goodsItemId = SCOPE_IDENTITY()
	END TRY
	BEGIN CATCH
		-- проверяем XACT_STATE()
		-- если 1, транзакцию можно закоммитить.  
		-- если -1, транзакцию закоммитить нельзя и она должна быть откачена.
		-- XACT_STATE = 0 означает, что мы вообще не в транзакции 
		--     и операции commit или rollback приведут к ошибке.
		IF (XACT_STATE()) = -1
			PRINT 'Rolling back the transaction'
		IF (XACT_STATE()) = -1
			ROLLBACK TRANSACTION;
		THROW;
	END CATCH

	-- в этой точке мы не знаем, пришли ли мы сюда
	-- после ошибки и отката транзакции или всё прошло гладко.
	-- Индикатором может быть наличие транзакции, которую можно
	-- завершить. Если такая есть - (XACT_STATE()) = 1 - то
	-- завершаем её.
	IF (XACT_STATE()) = 1
		COMMIT TRANSACTION;
	PRINT 'Transaction has been commited'
END
GO
-- проверяем, как работает наша процедура на данных для успешной вставки
-- когда не нужно создавать новую категорию
DELETE FROM dbo.Goods WHERE [Name] = 'Epson 200'
GO
EXECUTE dbo.CreateGoodsItem @categoryName = 'Print', @goodsItemName = 'Epson 200'
GO
SELECT * FROM dbo.Category
SELECT * FROM dbo.Goods
GO

-- проверяем, как работает наша процедура на данных для успешной вставки
-- когда нужно создавать новую категорию
DELETE FROM dbo.Goods WHERE [Name] = 'Lenovo Tab'
DELETE FROM dbo.Category WHERE [Name] = 'Tablet'
GO
EXECUTE dbo.CreateGoodsItem @categoryName = 'Tablet', @goodsItemName = 'Lenovo Tab'
GO
SELECT * FROM dbo.Category
SELECT * FROM dbo.Goods
GO

-- проверяем, как работает наша процедура на данных для НЕУСПЕШНОЙ вставки
-- когда нужно создавать новую категорию, но при заведении товара возникает
-- нарушение ограничения на уникальность имени товара
EXECUTE dbo.CreateGoodsItem @categoryName = 'Extra Tablet', @goodsItemName = 'Lenovo Tab'
GO
SELECT * FROM dbo.Category
SELECT * FROM dbo.Goods
GO
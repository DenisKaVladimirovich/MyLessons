USE QueryTests
GO
DROP FUNCTION IF EXISTS [dbo].[GetCategoryId]
GO
CREATE FUNCTION dbo.GetCategoryId (
	@categoryName AS VARCHAR(50) -- like in the field Name of table Category
)
RETURNS UNIQUEIDENTIFIER
AS
BEGIN
	-- объявляем переменную идентификатора
	DECLARE @guid AS UNIQUEIDENTIFIER

	-- пытаемся найти категорию по точному совпадению имени
	SELECT @guid = Id FROM dbo.Category WHERE [Name] = @categoryName

	-- если не нашли (@guid по-прежнему NULL)
	IF (@guid IS NULL)
	BEGIN
		-- ищем по совпадению начальных символов
		SELECT TOP 1 @guid = Id FROM dbo.Category WHERE [Name] LIKE @categoryName + '%'
	END

	-- возвращаем @guid результат 
	-- там всё ещё может быть NULL, если ничего не найдено даже 
	-- по совпадению начальных символов
	RETURN(@guid)
END
GO

-- проверяем, как работает наша функция на точном соответствии
SELECT dbo.GetCategoryId('TV')
-- проверяем, как работает наша функция на соответствии начальным символам
SELECT dbo.GetCategoryId('T')
-- проверяем, как работает наша функция на заведомо отсутствующем значении
SELECT dbo.GetCategoryId('D')
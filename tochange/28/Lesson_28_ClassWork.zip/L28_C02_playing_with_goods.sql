USE QueryTests;
GO
-- Создаём таблицу с автоинкрементным полем Id
-- DROP TABLE dbo.Goods 
CREATE TABLE dbo.Goods (
	Id INT NOT NULL IDENTITY(1,1),
	CategoryId UNIQUEIDENTIFIER NOT NULL,
	[Name] NVARCHAR(100) NOT NULL,
	CONSTRAINT PK_Goods PRIMARY KEY CLUSTERED (Id),
	-- с точки зрения бизнес-логики ограничение на уникальность
	-- лучше сделать по двум полям, однако это не очень вписывается
	-- в мой пример с откатом транзакции, поэтому я бы предложил
	-- оставить тут только одно поле [Name]
	--CONSTRAINT UQ_Goods_CategoryId_Name UNIQUE (CategoryId, [Name])
	CONSTRAINT UQ_Goods_Name UNIQUE ([Name])
);
GO
-- Вешаем на неё внешний ключ
ALTER TABLE dbo.[Goods] 
	ADD CONSTRAINT FK_Goods_CategoryId FOREIGN KEY (CategoryId)
		REFERENCES dbo.Category(Id);
GO
-- Определяем переменную типа UNIQUEIDENTIFIER
DECLARE @guid AS UNIQUEIDENTIFIER
-- Задаём переменной значение поля CategoryId
-- из таблицы dbo.Category где поле Name равно 'Mobile Phone'
SELECT @guid = Id
FROM dbo.Category AS C
WHERE C.[Name] = 'Mobile Phone'

-- Можем посмотреть значение этой переменной
PRINT @guid

-- GO писать нельзя, так как область видимости переменной @guid на этом завершится

-- Вставляем записи в таблицу с автоинкрементным полем,
-- где CategoryId заполняется из переменной @guid
INSERT INTO dbo.Goods (CategoryId, [Name]) VALUES (@guid, 'iPhone X')
-- системная функция SCOPE_IDENTITY() возвращает последний вставленный
-- в рамках данной сессии идентификаторв в автоинкрементное поле
PRINT 'ID of iPhone X is ' + CONVERT(VARCHAR(15), SCOPE_IDENTITY())

-- Функции CONVERT() и CAST() помогают приводить данные к нужному типу
INSERT INTO dbo.Goods (CategoryId, [Name]) VALUES (@guid, 'Xiaomi Mi 9')
PRINT 'ID of Xiaomi Mi 9 is ' + CAST(SCOPE_IDENTITY() AS VARCHAR(15))

-- Смотрим на содержимое таблицы Goods
SELECT * FROM dbo.Goods
GO
-- Полностью очищаем таблицу
-- (включая текущий счётчик 
-- автоинкремента поля Id
--TRUNCATE TABLE dbo.[Goods]

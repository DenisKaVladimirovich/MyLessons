USE QueryTests
GO
-- Чтобы было интересно сначала добавим одну пустую категорию
EXECUTE dbo.CreateCategory 'Other', NULL
SELECT * FROM dbo.Category
SELECT * FROM dbo.Goods

-- INNER JOIN
SELECT *
FROM dbo.Category
INNER JOIN dbo.Goods
	ON dbo.Goods.CategoryId = dbo.Category.Id

SELECT
	dbo.Goods.[Name],
	dbo.Category.[Name]
FROM dbo.Category
INNER JOIN dbo.Goods
	ON dbo.Goods.CategoryId = dbo.Category.Id
ORDER BY 2, 1

SELECT
	C.[Name],
	G.[Name],
	G.Id
FROM dbo.Category AS C WITH(NOLOCK)
INNER JOIN dbo.Goods AS G WITH(NOLOCK)
	ON G.CategoryId = C.Id
ORDER BY 1, 2

-- LEFT JOIN

-- выбрать все(!) категории и соответствующие им товары (если такие есть)
SELECT *
FROM dbo.Category AS C
LEFT JOIN dbo.Goods AS G
	ON G.CategoryId = C.Id

-- выбрать такие категории у которых нет ни одного товары
SELECT *
FROM dbo.Category AS C
LEFT JOIN dbo.Goods AS G
	ON G.CategoryId = C.Id
WHERE G.CategoryId IS NULL

-- RIGHT JOIN
-- поскольку у таблицы Goods стоит внешний ключ на таблицу Category наш RIGHT JOIN 
-- по факту вернёт то же самое, что и INNER JOIN
SELECT *
FROM dbo.Category AS C
RIGHT JOIN dbo.Goods AS G
	ON G.CategoryId = C.Id

-- FULL JOIN
-- поскольку у таблицы Goods стоит внешний ключ на таблицу Category наш FULL JOIN 
-- по факту вернёт то же самое, что и LEFT JOIN
SELECT *
FROM dbo.Category AS C
FULL JOIN dbo.Goods AS G
	ON G.CategoryId = C.Id

-- Статистические функции
-- Подсчёт количества
SELECT COUNT(Id)
FROM dbo.Goods

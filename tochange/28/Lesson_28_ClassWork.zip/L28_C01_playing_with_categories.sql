﻿CREATE DATABASE QueryTests;
GO
USE QueryTests;
GO
-- Создаём таблицу с GUID-полем
-- DROP TABLE dbo.[Category]
CREATE TABLE dbo.[Category] (
	Id UNIQUEIDENTIFIER NOT NULL,
	[Name] VARCHAR(50) NOT NULL,
	CONSTRAINT PK_Category PRIMARY KEY CLUSTERED (Id),
	CONSTRAINT UQ_Category_Name UNIQUE ([Name])
);
GO

-- Вставка значений
INSERT INTO dbo.[Category] (Id, [Name]) VALUES (NEWID(), 'Mobile Phones')
INSERT INTO dbo.[Category] (Id, [Name]) VALUES (NEWID(), 'TV')

-- Смотрим результат
SELECT Id, [Name] FROM dbo.[Category]
GO

-- Изменяем значение поля
UPDATE dbo.[Category]
	SET [Name] = 'Mobile Phone'
WHERE [Name] = 'Mobile Phones'

-- Смотрим результат
SELECT Id, [Name] FROM dbo.[Category]
GO

-- Попытка посторной вставки значений
INSERT INTO dbo.[Category] (Id, [Name]) VALUES (NEWID(), 'Mobile Phones')
INSERT INTO dbo.[Category] (Id, [Name]) VALUES (NEWID(), 'TV')

-- Смотрим результат подозрительным значениям
SELECT Id, [Name]
FROM dbo.[Category]
WHERE [Name] LIKE 'Mobile%'
ORDER BY [Name] ASC
GO

-- Удаляем лишнюю запись
DELETE FROM dbo.[Category]
WHERE [Name] = 'Mobile Phones'

-- Смотрим результат по всем значениям
SELECT Id, [Name] FROM dbo.[Category]
GO

-- Полностью очищаем таблицу
--TRUNCATE TABLE dbo.[Category]
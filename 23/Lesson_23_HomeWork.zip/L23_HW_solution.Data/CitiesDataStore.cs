﻿using System.Collections.Generic;
using L23_HW_solution.Core;

namespace L23_HW_solution.Data
{
	public class CitiesDataStore: ICitiesDataStore
	{
		public List<CityData> Cities { get; private set; }

		public CitiesDataStore()
		{
			Cities = new List<CityData>
			{
				new CityData
				{
					Id = 1,
					Name = "Moscow",
					Description = "The capital of Russia"
				},
				new CityData
				{
					Id = 2,
					Name = "New York",
					Description = "The one of the biggest cities in the world"
				}
			};
		}
	}
}

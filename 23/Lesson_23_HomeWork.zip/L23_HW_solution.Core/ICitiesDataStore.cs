﻿using System.Collections.Generic;

namespace L23_HW_solution.Core
{
	public interface ICitiesDataStore
	{
		List<CityData> Cities { get; }
	}
}

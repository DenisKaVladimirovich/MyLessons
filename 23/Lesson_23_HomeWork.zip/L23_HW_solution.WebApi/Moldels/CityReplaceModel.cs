﻿using System.ComponentModel.DataAnnotations;
using L23_HW_solution.Core;
using L23_HW_solution.WebApi.Validation;


namespace L23_HW_solution.WebApi.Moldels
{
	public class CityReplaceModel
	{
		[Required(ErrorMessage = "The name of the city is a required field")]
		[MaxLength(100)]
		public string Name { get; set; }

		[MaxLength(255)]
		[DifferentValue(OtherProperty = "Name")]
		public string Description { get; set; }

		[Range(0, 100)]
		public int NumberOfPointsOfInterest { get; set; }

		public CityReplaceModel()
		{
		}

		public CityReplaceModel(CityData city)
		{
			Name = city.Name;
			Description = city.Description;
			NumberOfPointsOfInterest = city.NumberOfPointsOfInterest;
		}
	}
}

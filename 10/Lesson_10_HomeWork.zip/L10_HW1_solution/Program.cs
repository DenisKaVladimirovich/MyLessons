using System;

internal class Program
{
	private static void Main()
	{
		// declaring the array for names
		Person[] persons = new Person[3];

		// requesting data
		for (int i = 0; i < persons.Length; i++)
		{
			persons[i] = new Person();

			Console.Write($"Enter name {i}: ");
			persons[i].Name = Console.ReadLine();

			Console.Write($"Enter age {i}: ");
			persons[i].Age = int.Parse(Console.ReadLine());
		}

		// Writing out the results
		for (int i = 0; i < persons.Length; i++)
		{
			Console.WriteLine(persons[i].PropertiesString);
		}
	}
}

internal class Person
{
	public string Name { get; set; }

	public int Age { get; set; }

	public int AgeInFourYears
	{
		get { return Age + 4; }
	}

	public string PropertiesString
	{
		get { return $"Name: {Name}, age in 4 years: {AgeInFourYears}."; }
	}

}
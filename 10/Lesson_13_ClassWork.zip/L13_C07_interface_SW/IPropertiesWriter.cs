﻿namespace L13_C07_interface_SW
{
	public interface IPropertiesWriter
	{
		void WriteAllProperties();

		void WriteAllProperties2();
	}
}

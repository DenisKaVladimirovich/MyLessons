﻿namespace L13_C06_interface.Interface
{
	public interface IVideoPlayer
	{
		string VideoSource { get; set; }

		void PlayVideo();
	}
}

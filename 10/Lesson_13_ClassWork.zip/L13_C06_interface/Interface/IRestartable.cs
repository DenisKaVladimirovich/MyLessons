﻿using System;
using System.Collections.Generic;
using System.Text;

namespace L13_C06_interface.Interface
{
	public interface IRestartable
	{
		void Restart();
	}
}

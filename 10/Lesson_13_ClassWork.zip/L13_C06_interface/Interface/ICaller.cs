﻿namespace L13_C06_interface.Interface
{
	public interface ICaller
	{
		void Call(string phoneNumber);
	}
}

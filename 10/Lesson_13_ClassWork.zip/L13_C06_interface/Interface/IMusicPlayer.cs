﻿namespace L13_C06_interface.Interface
{
	public interface IMusicPlayer
	{
		string MusicSource { get; set; }

		void PlayMusic();
	}
}

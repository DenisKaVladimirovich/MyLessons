﻿namespace L13_HW1_solution
{
	public enum LogRecordType
	{
		Info,
		Warning,
		Error
	}
}

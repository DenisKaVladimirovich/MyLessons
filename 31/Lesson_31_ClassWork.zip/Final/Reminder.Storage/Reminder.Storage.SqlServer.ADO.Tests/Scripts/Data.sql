﻿-- Fill some data
-- 1
INSERT INTO [dbo].[ReminderItem] (
	[Id],
	[ContactId],
	[TargetDate],
	[Message],
	[StatusId],
	[CreatedDate],
	[UpdatedDate]) 
VALUES (
	'00000000-0000-0000-0000-111111111111',
	'ContactId_1',
	'2020-01-01 00:00:00 +00:00',
	'Message_1',
	0,
	'2019-01-01 00:00:00 +00:00',
	'2019-01-01 00:00:00 +00:00')

using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Reminder.Storage.Core;

namespace Reminder.Storage.Sql.Tests
{
	[TestClass]
	public class SqlReminderStorageTests
	{
		private const string _connectionString =
			@"Data Source=localhost\SQLEXPRESS;Initial Catalog=ReminderTests;Integrated Security=true;";

		[TestInitialize]
		public void TestInitialize()
		{
			var dbInit = new SqlReminderStorageInit(_connectionString);
			dbInit.InitializeDatabase();
		}

		[TestMethod]
		public void Method_Add_Returns_Not_Empty_Guid()
		{
			var storage = new SqlReminderStorage(_connectionString);

			Guid actual = storage.Add(new Core.ReminderItemRestricted
			{
				ContactId = "TestContactId",
				Date = DateTimeOffset.Now.AddHours(1),
				Message = "Test Message",
				Status = Core.ReminderItemStatus.Awaiting
			});

			Assert.AreNotEqual(Guid.Empty, actual);
		}
	}
}

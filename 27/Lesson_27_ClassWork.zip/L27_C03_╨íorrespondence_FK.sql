USE Сorrespondence;
GO
-- Внешние ключи

-- ALTER TABLE dbo.Address DROP CONSTRAINT FK_Address_CityId
ALTER TABLE dbo.Address
ADD CONSTRAINT FK_Address_CityId FOREIGN KEY (CityId)
	REFERENCES dbo.City(Id)
	ON DELETE CASCADE
	ON UPDATE CASCADE
GO
-- ALTER TABLE dbo.Contractor DROP CONSTRAINT FK_Contractor_PositionId
ALTER TABLE dbo.Contractor
ADD CONSTRAINT FK_Contractor_PositionId FOREIGN KEY (PositionId)
	REFERENCES dbo.Position(Id)
	ON DELETE CASCADE
	ON UPDATE CASCADE
GO
-- ALTER TABLE dbo.SendingStatus DROP CONSTRAINT FK_SendingStatus_PostalItemItemId
ALTER TABLE dbo.SendingStatus
ADD CONSTRAINT FK_SendingStatus_PostalItemItemId FOREIGN KEY (PostalItemItemId)
	REFERENCES dbo.PostalItem(Id)
	ON DELETE CASCADE
	ON UPDATE CASCADE
GO
-- ALTER TABLE dbo.SendingStatus DROP CONSTRAINT FK_SendingStatus_StatusId
ALTER TABLE dbo.SendingStatus
ADD CONSTRAINT FK_SendingStatus_StatusId FOREIGN KEY (StatusId)
	REFERENCES dbo.Status(Id)
	ON DELETE CASCADE
	ON UPDATE CASCADE
GO
-- ALTER TABLE dbo.SendingStatus DROP CONSTRAINT FK_SendingStatus_SendingContractorId
ALTER TABLE dbo.SendingStatus
ADD CONSTRAINT FK_SendingStatus_SendingContractorId FOREIGN KEY (SendingContractorId)
	REFERENCES dbo.Contractor(Id)
GO
-- ALTER TABLE dbo.SendingStatus DROP CONSTRAINT FK_SendingStatus_SendingAddressId
ALTER TABLE dbo.SendingStatus
ADD CONSTRAINT FK_SendingStatus_SendingAddressId FOREIGN KEY (SendingAddressId)
	REFERENCES dbo.Address(Id)
GO
-- ALTER TABLE dbo.ReceivingStatus DROP CONSTRAINT FK_ReceivingStatus_ReceivingContractorId
ALTER TABLE dbo.SendingStatus
ADD CONSTRAINT FK_ReceivingStatus_ReceivingContractorId FOREIGN KEY (ReceivingContractorId)
	REFERENCES dbo.Contractor(Id)
GO
-- ALTER TABLE dbo.ReceivingStatus DROP CONSTRAINT FK_ReceivingStatus_ReceivingAddressId
ALTER TABLE dbo.SendingStatus
ADD CONSTRAINT FK_ReceivingStatus_ReceivingAddressId FOREIGN KEY (ReceivingAddressId)
	REFERENCES dbo.Address(Id)
GO
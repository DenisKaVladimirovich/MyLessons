CREATE DATABASE Сorrespondence;
GO

USE Сorrespondence;
GO

-- Отправление
-- DROP TABLE dbo.PostalItem
CREATE TABLE dbo.PostalItem (
	Id INT NOT NULL,
	[Name] VARCHAR(250) NOT NULL,
	NumberOfPages INT NOT NULL,
);
GO

-- Контрагент
-- DROP TABLE dbo.Сontractor
CREATE TABLE dbo.Сontractor (
	Id INT NOT NULL,
	[Name] VARCHAR(250) NOT NULL,
	PositionId INT NOT NULL,
);
GO

-- Позиция
-- DROP TABLE dbo.Position
CREATE TABLE dbo.Position (
	Id INT NOT NULL,
	[Name] VARCHAR(250) NOT NULL,
);
GO

-- Город
-- DROP TABLE dbo.City
CREATE TABLE dbo.City (
	Id INT NOT NULL,
	[Name] VARCHAR(250) NOT NULL,
);
GO

-- Адрес
-- DROP TABLE dbo.Address
CREATE TABLE dbo.Address (
	Id INT NOT NULL,
	CityId INT NOT NULL,
	[Address] VARCHAR(250) NOT NULL,
);
GO

-- Статус
-- DROP TABLE dbo.Status
CREATE TABLE dbo.Status (
	Id INT NOT NULL,
	[Name] VARCHAR(20) NOT NULL,
);
GO

-- Статус
-- DROP TABLE dbo.SendingStatus
CREATE TABLE dbo.SendingStatus (
	SendingContractorId INT NOT NULL,
	SendingAddressId INT NOT NULL,
	ReceivingContractorId INT NOT NULL,
	ReceivingAddressId INT NOT NULL,
	PostalItemItemId INT NOT NULL,
	StatusId INT NOT NULL,
	UpdateStatusDateTime DATETIMEOFFSET NOT NULL,
);
GO

USE Сorrespondence;
GO
-- проверка на уникальность одного поля
-- ALTER TABLE dbo.City DROP CONSTRAINT UQ_City_Name;
ALTER TABLE dbo.City
ADD CONSTRAINT UQ_City_Name UNIQUE (Name);
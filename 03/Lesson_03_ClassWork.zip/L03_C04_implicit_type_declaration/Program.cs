class Program
{
	static void Main()
	{
		// Explicit type declaration
		var population = 66_000_000;
		var weight = 25;
		var height = 1.88F;
		var price = 4.99M;
		var fruit = "Apples";
		var letter = 'Z';
		var happy = true;
	}
}
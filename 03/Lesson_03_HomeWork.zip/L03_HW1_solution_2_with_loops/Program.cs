using System;

class Program
{
	static void Main()
	{
		// declaring the array for names
		string[] names = new string[3];

		for (int i = 0; i < names.Length; i++)
		{
			Console.Write($"Enter name {i}: ");
			names[i] = Console.ReadLine();
		}

		// declaring the array for ages
		int[] ages = new int[3];

		for (int i = 0; i < ages.Length; i++)
		{
			Console.Write($"Enter age {i}: ");
			ages[i] = int.Parse(Console.ReadLine());
		}

		// calculations

		int[] ageInFourYears = new int[3];

		for (int i = 0; i < ageInFourYears.Length; i++)
		{
			ageInFourYears[i] = ages[i] + 4;
		}

		// Writing out the results
		for (int i = 0; i < ageInFourYears.Length; i++)
		{
			Console.WriteLine($"Name: {names[i]}, age in 4 years: {ageInFourYears[i]}.");
		}
	}
}
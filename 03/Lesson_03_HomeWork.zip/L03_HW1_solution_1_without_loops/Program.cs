using System;

class Program
{
	static void Main()
	{
		// declaring the array for names
		string[] names = new string[3];

		Console.Write("Enter name 1: ");
		names[0] = Console.ReadLine();

		Console.Write("Enter name 2: ");
		names[1] = Console.ReadLine();

		Console.Write("Enter name 3: ");
		names[2] = Console.ReadLine();

		// declaring the array for ages
		int[] ages = new int[3];

		Console.Write("Enter age 1: ");
		ages[0] = int.Parse(Console.ReadLine());

		Console.Write("Enter age 2: ");
		ages[1] = int.Parse(Console.ReadLine());

		Console.Write("Enter age 3: ");
		ages[2] = int.Parse(Console.ReadLine());

		// calculations

		int[] ageInFourYears = new int[3];

		ageInFourYears[0] = ages[0] + 4;
		ageInFourYears[1] = ages[1] + 4;
		ageInFourYears[2] = ages[2] + 4;

		// Writing out the results

		Console.WriteLine($"Name: {names[0]}, age in 4 years: {ageInFourYears[0]}.");
		Console.WriteLine($"Name: {names[1]}, age in 4 years: {ageInFourYears[1]}.");
		Console.WriteLine($"Name: {names[2]}, age in 4 years: {ageInFourYears[2]}.");
	}
}
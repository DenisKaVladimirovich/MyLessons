﻿using System;

namespace L11_HW1_solution
{
	class Program
	{
		static void Main()
		{
			var r1 = new ReminderItem(DateTimeOffset.Parse("2020-03-14"), "Happy birthday!");
			r1.WriteProperties();
		}
	}
}

using System;

public class Program
{
	public static void Main()
	{
		int x = 0;
		x = x + 1;
	}
}

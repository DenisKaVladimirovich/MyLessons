﻿namespace L14_HW1_solution
{
	public enum LogRecordType
	{
		Info,
		Warning,
		Error
	}
}

USE [LiveHeroTour2]
GO
-- Группировки

-- Общее количество обработанных заказов
SELECT COUNT(*)
FROM [dbo].[Order] AS O

-- Количество обработанных заказов сгруппированных по годам
SELECT YEAR(O.[OrderDate]), COUNT(*)
FROM [dbo].[Order] AS O
GROUP BY YEAR(O.[OrderDate])

-- ID и даты заказов с полной итоговой суммой заказа
SELECT 
	O.[Id],
	O.[OrderDate],
	SUM(P.[Price] * OI.NumberOfItems) AS [Total]
FROM [dbo].[Order] AS O
INNER JOIN [dbo].[OrderItem] AS OI
	ON OI.[OrderId] = O.[Id]
INNER JOIN [dbo].[Product] AS P
	ON P.[Id] = OI.[ProductId]
GROUP BY O.[Id], O.[OrderDate]

-- Расчёт денег, потраченных Марией с учётом скидки к каждому товару
SELECT SUM(T.Total)
FROM
	(SELECT 
		(1 - ISNULL(O.Discount,0)) * SUM(P.[Price] * OI.NumberOfItems) AS Total
	FROM [dbo].[Order] AS O
	INNER JOIN [dbo].[OrderItem] AS OI
		ON OI.[OrderId] = O.[Id]
	INNER JOIN [dbo].[Product] AS P
		ON P.[Id] = OI.[ProductId]
	INNER JOIN [dbo].[Customer] AS C
		ON C.[Id] = O.[CustomerId]
	WHERE C.[Name] = 'Мария'
	GROUP BY O.Discount
) AS T

-- Вычисление доли денежных расходов Марии по отношению к расходом всех покупателей
SELECT (
		SELECT SUM(P.[Price] * OI.NumberOfItems) AS [Total]
		FROM [dbo].[Order] AS O
		INNER JOIN [dbo].[OrderItem] AS OI
			ON OI.[OrderId] = O.[Id]
		INNER JOIN [dbo].[Product] AS P
			ON P.[Id] = OI.[ProductId]
		INNER JOIN [dbo].[Customer] AS C
			ON C.[Id] = O.[CustomerId]
		WHERE C.[Name] = 'Мария'
	) / (
			SELECT SUM(P.[Price] * OI.NumberOfItems) AS [Total]
		FROM [dbo].[Order] AS O
		INNER JOIN [dbo].[OrderItem] AS OI
			ON OI.[OrderId] = O.[Id]
		INNER JOIN [dbo].[Product] AS P
			ON P.[Id] = OI.[ProductId]
		INNER JOIN [dbo].[Customer] AS C
			ON C.[Id] = O.[CustomerId]
	)

-- Решение задачи в общем виде:
-- Сумма денег, потраченная каждым покупателем
-- И доля по отношению ко всем
DECLARE @total AS MONEY
SELECT @total = SUM(T.[Sum])
FROM
(
	SELECT
		C.[Name],
		(1 - ISNULL(O.Discount,0)) * SUM(P.[Price] * OI.NumberOfItems) AS [Sum]
	FROM [dbo].[Order] AS O
	INNER JOIN [dbo].[OrderItem] AS OI
		ON OI.[OrderId] = O.[Id]
	INNER JOIN [dbo].[Product] AS P
		ON P.[Id] = OI.[ProductId]
	RIGHT JOIN [dbo].[Customer] AS C
		ON C.[Id] = O.[CustomerId]
	GROUP BY O.Discount, C.[Name]
) AS T

SELECT
	T.[Name],
	SUM(T.[Sum]) AS [Sum],
	SUM(T.[Sum]) / @total AS [Percentage]
FROM
(
	SELECT
		C.[Name],
		(1 - ISNULL(O.Discount,0)) * SUM(P.[Price] * OI.NumberOfItems) AS [Sum]
	FROM [dbo].[Order] AS O
	INNER JOIN [dbo].[OrderItem] AS OI
		ON OI.[OrderId] = O.[Id]
	INNER JOIN [dbo].[Product] AS P
		ON P.[Id] = OI.[ProductId]
	RIGHT JOIN [dbo].[Customer] AS C
		ON C.[Id] = O.[CustomerId]
	GROUP BY O.Discount, C.[Name]
) AS T
GROUP BY T.[Name]
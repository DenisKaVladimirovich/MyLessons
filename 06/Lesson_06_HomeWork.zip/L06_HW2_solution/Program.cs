﻿using System;

class Program
{
	static void Main()
	{
		decimal firstPay;
		decimal dailyIncrement;
		decimal targetSum;
		try
		{
			Console.WriteLine("Введите сумму первоначального взноса в рублях: ");
			firstPay = decimal.Parse(Console.ReadLine());

			Console.WriteLine("Введите ежедневный процент дохода в виде десятичной дроби (1% = 0.01): ");
			dailyIncrement = decimal.Parse(Console.ReadLine());

			Console.WriteLine("Введите желаемую сумму накопления в рублях: ");
			targetSum = decimal.Parse(Console.ReadLine());
		}
		catch (FormatException e)
		{
			Console.WriteLine("Ошибка! Введено нечисловое значение, невозможно продолжить вычисление:");
			Console.WriteLine($"{e.GetType()}: {e.Message}");
			throw;
		}
		catch (Exception e)
		{
			Console.WriteLine("Неожиданная ошибка! невозможно продолжить вычисление:");
			Console.WriteLine($"{e.GetType()}: {e.Message}");
			throw;
		}


		int numberOfDays = 0;
		decimal sum = firstPay;
		
		while(sum < targetSum)
		{
			sum = sum + sum * dailyIncrement;
			numberOfDays++;
		}

		Console.WriteLine($"Необходимое количество дней для накопления желаемой суммы: {numberOfDays}.");

		Console.WriteLine("Нажмите любую клавишу для выхода...");
		Console.ReadKey();
	}
}
﻿using System;

class Program
{
	static void Main()
	{
		int number = -1;

		Console.WriteLine("Введите положительное натуральное число: ");
		do
		{
			try
			{
				number = int.Parse(Console.ReadLine());
			}
			catch (FormatException)
			{
				Console.WriteLine("Введено неверное значение. Попробуйте ещё раз:");
			}

		} while (number < 0);

		string strNumber = number.ToString();
		byte numberOfEvenDigits = 0;
		foreach (char strDigit in strNumber)
		{
			byte digit = (byte) strDigit;
			if (digit % 2 == 0)
			{
				numberOfEvenDigits++;
			}
		}

		Console.WriteLine($"В числе {number} содержится следующее количество четных цифр: {numberOfEvenDigits}.");

		Console.WriteLine("Нажмите любую клавишу для выхода...");
		Console.ReadKey();
	}
}